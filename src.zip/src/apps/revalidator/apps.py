from django.apps import AppConfig

class RevalidatorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.revalidator"