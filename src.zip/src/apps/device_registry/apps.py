from django.apps import AppConfig

class DeviceRegistryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'src.apps.device_registry'
